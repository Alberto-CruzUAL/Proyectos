
t = 3;


R = 6.35;       % [m] distance
Rp = 0.35;      % [m/s]
Rpp = 0;        % [m/s²]


th = 2.943;     % [rad] azimuth
thp = 0.4725;   % [rad/s]
thpp = 0.015;    % [rad/s²]

phi = 0.6027;   % [rad] elevation
phip = 0.26;    % [rad/s]
phipp = 0.02;   % [rad/s²]


vR = Rp;
vth = R * thp * cos(phi);
vphi = R * phip;
v = sqrt(vR^2 + vth^2 + vphi^2);


aR = Rpp - R * phip^2 - R * thp^2 * cos(phi)^2;
ath = (cos(phi)/R) * (R^2 * thpp + 2 * R * Rp * thp) - 2 * R * thp * phip * sin(phi);
aphi = (1/R) * (R^2 * phipp + 2 * R * Rp * phip) + R * thp^2 * sin(phi) * cos(phi);
a = sqrt(aR^2 + ath^2 + aphi^2);


fprintf('--- Resultados en t = %.1f s ---\n', t);
fprintf('Velocidad total (v): %.4f m/s\n', v);
fprintf('Aceleración total (a): %.4f m/s²\n\n', a);

fprintf('Componentes de velocidad:\n');
fprintf('  vR = %.4f m/s\n', vR);
fprintf('  vθ = %.4f m/s\n', vth);
fprintf('  vφ = %.4f m/s\n\n', vphi);

fprintf('Componentes de aceleración:\n');
fprintf('  aR = %.4f m/s²\n', aR);
fprintf('  aθ = %.4f m/s²\n', ath);
fprintf('  aφ = %.4f m/s²\n', aphi);