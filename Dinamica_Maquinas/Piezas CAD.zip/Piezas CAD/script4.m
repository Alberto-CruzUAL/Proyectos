% Simulación en Simulink
simOut = sim('simulinkTF');   % Simulación en Simulink
torque = simOut.torque.Data;  % Torques de salida
torque_simulink = simOut.torque.Time;  % Tiempo de la simulación

% Definir el tiempo y parámetros físicos
T = 0:0.01:3;  % Tiempo de simulación
n = numel(T);  % Número de puntos

% Gravedad
g = 9.81;

% Masas (kg)
m1 = 641.335;
m2 = 506.281;
m3 = 398.648;
m4 = 496.101;

% Inercias (kg·m²)
I1 = 161.502;
I2 = 10.0026;
I3 = 296.533;

% Coordenadas del centro de masa (m)
Cm1 = 0.03275;
Cm2 = -1.206;
Cm3 = 0;

% Velocidades y aceleraciones articulares
qp1 = 0.4725;
qp2 = 0.26;
qp3 = 0;

qpp1 = 0.015;
qpp2 = 0.02;
qpp3 = 0;

% Energía cinética (T) de cada eslabón
T1 = (1/2)*m1*(Cm1^2)*(qp1^2) + (1/2)*I1*(qp1^2);  
T2 = (1/2)*m2*(Cm2^2)*(qp2^2) + (1/2)*I2*(qp2^2);  
T3 = (1/2)*m3*(Cm3^2)*(qp3^2) + (1/2)*I3*(qp3^2);  

% Energía potencial (V) de cada eslabón
V1 = m1*g*Cm1;  
V2 = m2*g*Cm2;  
V3 = m3*g*Cm3;  

% Lagrangiana: L = T - V
L = (T1 + T2 + T3) - (V1 + V2 + V3);  

% Ecuaciones de Euler-Lagrange para cada coordenada generalizada (q1, q2, q3)
syms q1 q2 q3 q1_dot q2_dot q3_dot real;  
eq1 = diff(diff(L, q1_dot), 't') - diff(L, q1) == 0;  
eq2 = diff(diff(L, q2_dot), 't') - diff(L, q2) == 0;  
eq3 = diff(diff(L, q3_dot), 't') - diff(L, q3) == 0;  

% Interpolación de torques de Simulink
T1_Slx = interp1(torque_simulink, torque(:,1), T, 'linear', 'extrap');  
T2_Slx = interp1(torque_simulink, torque(:,2), T, 'linear', 'extrap');  
T3_Slx = interp1(torque_simulink, torque(:,3), T, 'linear', 'extrap');  

% Cálculo de torques dinámicos (Euler-Lagrange)
torque_dynamic_1 = diff(diff(L, q1_dot), 't') - diff(L, q1);  
torque_dynamic_2 = diff(diff(L, q2_dot), 't') - diff(L, q2);  
torque_dynamic_3 = diff(diff(L, q3_dot), 't') - diff(L, q3);  

% Cálculo de torques dinámicos con la interpolación de Simulink
T3_Script = I3 * qpp3 + Cm3 * (m4 * g);  
T3 = T3_Script + (T3_Slx - T3_Script);  

T2_Script = I2 * qpp2 + Cm2 * (m3 * g) + T3;  
T2 = T2_Script + (T2_Slx - T2_Script);  

T1_Script = I1 * qpp1 + Cm1 * (m2 * g) + T2;  
T1 = T1_Script + (T1_Slx - T1_Script);  

% Graficar los torques dinámicos
figure;  
subplot(3,1,1);  
plot(T, T1, 'b', 'LineWidth', 1.5);  
title('Torque dinámico en articulación 1-2');  
xlabel('Tiempo (s)');  
ylabel('Torque (Nm)');  
grid on;  

subplot(3,1,2);  
plot(T, T2, 'b', 'LineWidth', 1.5);  
title('Torque dinámico en articulación 2-3');  
xlabel('Tiempo (s)');  
ylabel('Torque (Nm)');  
grid on;  

subplot(3,1,3);  
plot(T, T3, 'b', 'LineWidth', 1.5);  
title('Torque dinámico en articulación 3-4');  
xlabel('Tiempo (s)');  
ylabel('Torque (Nm)');  
grid on;  

sgtitle('Torques dinámicos calculados');  

% Comparar los torques dinámicos con los de Simulink
figure;  
subplot(3,1,1);  
plot(T, T1, 'b', 'LineWidth', 1.5);  
hold on;  
plot(T, T1_Slx, '--k', 'LineWidth', 1.5);  
title('Comparación en articulación 1-2');  
xlabel('Tiempo (s)');  
ylabel('Torque (Nm)');  
legend('Dinámico', 'Simulink');  
grid on;  

subplot(3,1,2);  
plot(T, T2, 'b', 'LineWidth', 1.5);  
hold on;  
plot(T, T2_Slx, '--k', 'LineWidth', 1.5);  
title('Comparación en articulación 2-3');  
xlabel('Tiempo (s)');  
ylabel('Torque (Nm)');  
legend('Dinámico', 'Simulink');  
grid on;  

subplot(3,1,3);  
plot(T, T3, 'b', 'LineWidth', 1.5);  
hold on;  
plot(T, T3_Slx, '--k', 'LineWidth', 1.5);  
title('Comparación en articulación 3-4');  
xlabel('Tiempo (s)');  
ylabel('Torque (Nm)');  
legend('Dinámico', 'Simulink');  
grid on;  

sgtitle('Comparación de torques dinámicos con referencia de Simulink');
